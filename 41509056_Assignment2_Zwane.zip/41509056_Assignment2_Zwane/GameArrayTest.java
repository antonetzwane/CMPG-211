
/**
 * Write a description of class GameArrayTest here.
 *
 * @author (Antonet Zwane)
 * @version (16 August 2023)
 */
public class GameArrayTest
{
    //41509056 Antonet Zwane.
    private static void printCards(GameArrayList card) 
    {
        //Cards must be displayed or printed.
        for (int i = 0; i < card.size(); i++) {
            System.out.print(card.get(i) + " ");
            if ((i + 1) % 4 == 0) {
                System.out.println();
            }
        }
        System.out.println();
    }
    
    public static void main(String[] args) 
    {
        //The ArrayList to store the integers.
        GameArrayList card = new GameArrayList();//<GameOfCards>

        //Adding the integers or elements to the list/Adding the 16 cards. 
        //for (int i = 1; i <= 4; i++)
        for (int i = 1; i <= 8; i++)
        {
            card.add(new GameOfCards(i));
            card.add(new GameOfCards(i));
            //cardList.add(new GameOfCards(i));
            //cardList.add(new GameOfCards(i));
        }
        
        //printCards(card);//These are the cards before counting.
        
        // The countNumber method.
        GameOfCards countTest = new GameOfCards(3);
        int count = card.countNumber(countTest);
        System.out.println(count + " cards have similar values from these 16 cards.");
        
        //The player must guess a card and it must be displayed.
        GameOfCards guessedCard = card.get(5);
        guessedCard.setGuessed(true);
        printCards(card);
    }

    
}
