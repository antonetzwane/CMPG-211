
/**
 * Write a description of class GameArrayList here.
 *
 * @author (Antonet Zwane)
 * @version (16 August 2023)
 */
import java.util.ArrayList;
public class GameArrayList extends ArrayList<GameOfCards>
{
    //41509056 Antonet Zwane
    
    //private int size;
    //private E[] cardData;
    //countNumber methods for the ArrayList and for storing the numbers in the list.
    public int countNumber(GameOfCards card)
    {
        int numberCount = 0;
        for (GameOfCards gameCard : this) 
        {
            if (gameCard.equals(card))
            {
                numberCount++;
            }
        }
        return numberCount;
    }
}
