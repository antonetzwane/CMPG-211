
/**
 * Write a description of class GameOfCards here.
 *
 * @author (Antonet Zwane)
 * @version (16 August 2023)
 */
public class GameOfCards
{
    //41509056 Antonet Zwane.
    
    //Instances or variables to be used in the program.
    public int value = 0;
    public boolean guessed;

    //Default and non-default constructors.
    public GameOfCards()
    {
        
    }
    public GameOfCards(int value) 
    {
        setValue(value);
        setGuessed(guessed);
        //this.guessed = false;
    }

    // Accessors methods.
    public int getValue()//int value
    {
        return value;
    }
    public boolean isGuessed(boolean guessed) 
    {
        return guessed;
    }

    //Mutators methods.
    public void setGuessed(boolean guessed) 
    {
        this.guessed = false;
    }
    public void setValue(int value)
    {
        this.value = value;
    }

    //Override the toString method.
    @Override
    public String toString() 
    {
        //Declaring a game instance to be used in the program.
        String game ="";
        if (guessed)
        {
            return game.toString() + "]";
            //return Integer.toString(value);
        } else 
        {
            // Cards are displayed by # if the are not guessed.
            return "#"; 
        }
    }

    //Override the equals method.
    @Override
    public boolean equals(Object objCard) 
    {
        if (this == objCard) 
        {
            return true;
        }
        if (objCard == null || getClass() != objCard.getClass()) 
        {
            return false;
        }
        GameOfCards card = (GameOfCards) objCard;
        return value == card.value;
    }
}
