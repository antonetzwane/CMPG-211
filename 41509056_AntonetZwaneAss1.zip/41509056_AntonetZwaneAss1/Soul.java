
/**
 * Write a description of class Soul here.
 *
 * @author (Antonet Zwane)
 * @version (26/07/2023)
 */
public class Soul extends MusicGenre
{
    // Antonet Zwane 41509056
    
    public String vocalist;
    public Soul()
    {
        
    }
    public Soul(String artist, String songTitle, int songDuration, int releaseYear,  String vocalist)
    {
        super(artist, songTitle, songDuration, releaseYear);
        setVocalist(vocalist);
    }
    
    //Accessor method.
    public String getVocalist(String vocalist)
    {
        return vocalist;
    }
    
    //Mutator method.
    public void setVocalist(String vocalist)
    {
        this.vocalist = vocalist;
    }
    
    //Implementing the abstract method in the superclass.
    public double performanceFee()
    {
        double performanceFee = 75000 * 2;//The duration/hours performing;
        return performanceFee;
    }
    
    //Override method.
    @Override
    public String toString()
    {
        //String music = String.format("%-15s %-15s", super.toString(), vocalis);
        return super.toString() + " Vocalist: " + vocalist;
    }
}
