
/**
 * Write a description of class Test here.
 *
 * @author (Antonet Zwane)
 * @version (26/07/2023)
 */
public class Test
{
    // Antonet Zwane 41509056
    
    //Main method.
    public static void main(String[] args)
    {
        MusicGenre genreH = new HipHop("NastyC ", "Phases", 3, 2016, "Rowlene");        
        MusicGenre genreS = new Soul("Ayanda Jiya","Lover4Life", 3, 2019,"Stogie T");
        
        
        //Calling the abstract methods from the HipHop and Soul subclasses.
        genreH.performanceFee();
        genreS.performanceFee();
        
        //Calling the toString() method implicit and explicit.
        System.out.println("\n" + genreH.toString() + "\t" + "PerformanceFee: R" + genreH.performanceFee());//Explicit.
        System.out.print("\n" + genreS + "\t" + "PerformanceFee: R" + genreS.performanceFee());//Implicit.
    }
}
