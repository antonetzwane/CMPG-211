
/**
 * Write a description of class HipHop here.
 *
 * @author (Antonet Zwane)
 * @version (26/07/2023)
 */
public class HipHop extends MusicGenre
{
    //Antonet Zwane 41509056
    public String feature;
    
    public HipHop()
    {
        
    }
    public HipHop(String artist, String songTitle, int songDuration, int releaseYear ,String feature)
    {
        super(artist, songTitle, songDuration, releaseYear);
        setFeature(feature);
    }
    
    //Accessor methods.
    public String getRappers(String feature)
    {
        return feature;
    }
    
    //Mutator method.
    public void setFeature(String rappers)
    {
        this.feature = feature;
    }
    
    //Implementing the abstract method in the superclass.
    public double performanceFee()
    {
        double performanceFee = 50000 * 2;//The duration/hours performing;
        return performanceFee;
    }
    
    //Override method.
    @Override
    public String toString()
    {
        //String music = String.format("%-15s %-15s", super.toString(), rappers);
        return super.toString() + " Rapper: " + feature;
    }
}
