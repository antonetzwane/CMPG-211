
/**
 * Write a description of class MusicGenre here.
 *
 * @author (Antonet Zwane)
 * @version (26/07/2023)
 */
public abstract class MusicGenre 
{
    //Antonet Zwane 41509056
    
    //Fields/Variable to be used in the program.
    public String artist;
    public String songTitle;
    public int songDuration;
    public int releaseYear;
    
    //Constructors.
    public MusicGenre()
    {
        
    }
    public MusicGenre(String artist, String songTitle, int songDuration, int releaseYear)
    {
        setArtist(artist);
        setTitle(songTitle);
        setDuration(songDuration);
        setYear(releaseYear);
    }
    
    //Accessor Methods.
    public String getArtist(String artist)
    {
        return artist;
    }
    public String getTitle(String songTitle)
    {
        return songTitle;
    }
    public int getDuration(int songDuration)
    {
        return songDuration;
    }
    public int getYear(int releaseYear)
    {
        return releaseYear;
    }
    
    //Mutator methods.
    public void setArtist(String artist)
    {
        this.artist = artist;
    }
    public void setTitle(String songTitle)
    {
        this.songTitle = songTitle;
    }
    public void setDuration(int songDuration)
    {
        this.songDuration = songDuration;
    }
    public void setYear(int releaseYear)
    {
        this.releaseYear = releaseYear;
    }
    
    //Abstract method.
    public abstract double performanceFee();
    
    //Override method.
    @Override
    public String toString()
    {
        //String music = String.format("%-15s %-15s %-8d %-10d", artist, songTitle, songDuration, releaseYear);
        return "Artist: " + artist + "\t" + "Title: " + songTitle + "\t" + "Duration: " + songDuration + "\t" + "Year: " + releaseYear;
    }
}
